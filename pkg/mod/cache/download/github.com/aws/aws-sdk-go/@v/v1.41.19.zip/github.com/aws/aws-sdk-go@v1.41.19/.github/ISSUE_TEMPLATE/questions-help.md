---
name: "\U0001F4AC Questions / Help"
about: If you have questions, please check AWS Forums or StackOverflow
title: ''
labels: needs-triage, guidance
assignees: ''

---

Confirm by changing [ ] to [x] below:
- [ ] I've gone though [Developer Guide](https://docs.aws.amazon.com/sdk-for-go/v1/developer-guide/welcome.html) and [API reference](https://docs.aws.amazon.com/sdk-for-go/api/)
- [ ] I've checked [AWS Forums](https://forums.aws.amazon.com) and [StackOverflow](https://stackoverflow.com/questions/tagged/aws-sdk-go) for answers

**Describe the question**